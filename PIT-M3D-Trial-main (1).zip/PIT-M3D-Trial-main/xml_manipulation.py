# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

""" Part 2 Answer: 
    Abnormal blood concentration levels are 
    typically mmuch higher and have a higher variance
    when compared to normal concentration levels """
    
    
    
"""
    Part 3
"""

    
import xml.etree.ElementTree as ET
import pandas as pd

column_names = ["Accession Number","Biospecimen","Disease/Status"]

finalList = pd.DataFrame(columns = column_names)

print(finalList)

XML_with_blood = []


for count in range(1,4817):
    numString = str(count)
    
    normal_counter = 0
    abnormal_counter = 0
    
    blood_normal_counter = 0
    blood_abnormal_counter = 0
    
    if count < 10:
        numString = '0' + numString
    
    fileString = '/home/guest/Desktop/xml_split_5000/hmdb_metabolites-' + numString + '.xml'
    #print(fileString)
    
    
    tree = ET.parse(fileString)
    
    root = tree.getroot()
    
    #print(root.tag)
    #for child in root:
    #    print(child.tag, child.attrib)
    
    accessionNo = None
    for accession in root.iter('accession'):
        accessionNo = accession.text
    
    #print(accessionNo)
    
    biospecimenNormalList = []
    subject_conditionList = []
    
    for normal_concentrations in root.iter('normal_concentrations'):
        #print(normal_concentrations)
        for concentration in normal_concentrations.iter('concentration'):
            #print(concentration.attrib)
            for biospecimen in concentration.iter('biospecimen'):
                normal_counter = normal_counter + 1
                biospecimenNormalList.append(biospecimen.text)
                if (biospecimen.text == 'Blood'):
                    blood_normal_counter = blood_normal_counter + 1;
            for subject_condition in concentration.iter('subject_condition'):
                subject_conditionList.append(subject_condition.text)
                normal_counter = normal_counter + 1
    #print(biospecimenNormalList)
    #print(subject_conditionList)
    
    biospecimenAbnormalList = []
    patient_informationList = []
        
    for abnormal_concentrations in root.iter('abnormal_concentrations'):
        #print(normal_concentrations)
        for concentration in abnormal_concentrations.iter('concentration'):
            #print(concentration)
            for biospecimen in concentration.iter('biospecimen'):
                abnormal_counter = abnormal_counter + 1
                biospecimenAbnormalList.append(biospecimen.text)
                if (biospecimen.text == 'Blood'):
                    blood_abnormal_counter = blood_abnormal_counter + 1;
            for patient_information in concentration.iter('patient_information'):
                patient_informationList.append(patient_information.text)
                abnormal_counter = abnormal_counter + 1
    #print(biospecimenAbnormalList)
    #print(patient_informationList)
        
    #print(blood_normal_counter, blood_abnormal_counter)
    
    " Creation of final list for processing into csv file "
    
    if (normal_counter != 0 or abnormal_counter != 0):
        d=pd.DataFrame(biospecimenNormalList)
        e=pd.DataFrame(subject_conditionList)
        
        mergedNormal=pd.concat([d,e],axis=1)
        
        f=pd.DataFrame(biospecimenAbnormalList)
        g=pd.DataFrame(patient_informationList)
        
        mergedAbnormal=pd.concat([f,g],axis=1)
        
        finalMerge = pd.concat([mergedNormal, mergedAbnormal],axis=0)
        
        #print(finalMerge)
        
        finalMerge.insert(0, 'Accession Number', accessionNo)
        
        finalMerge.columns= finalList.columns
        
        finalMerge = finalMerge.reset_index(drop=True)
        
        finalMerge = finalMerge.drop_duplicates()
        
        #print(finalMerge)
        
        finalList = finalList.reset_index(drop=True)
    
        finalList = finalList.append(finalMerge)
        
        #print(finalList)
        
        finalList = finalList.drop_duplicates()
        
        print(finalList)
        
    " Marking of files that have both normal and abnormal concentrations tag "
    
    if (blood_normal_counter != 0 and blood_abnormal_counter != 0):
        XML_with_blood.append(count)
        

#print(finalList)
        
finalList.to_csv('/home/guest/Desktop/outputFiles/out.csv')

print(len(XML_with_blood))
print(XML_with_blood)







"""
    Part 4 - 5
"""

"""
    metabolites
        creation_date
        update_date
        accession
        name
        normal_concentrations
            all of it
        abnormal_concentrations
            all of it
        diseases 
            all of it
"""

from xml.dom import minidom

for fileNum in XML_with_blood:
    
    numString2 = str(fileNum)
    
    if fileNum < 10:
        numString2 = '0' + numString2

    fileString2 = "/home/guest/Desktop/xml_split_5000/hmdb_metabolites-" + numString2 + ".xml"
    
    mydoc = minidom.parse(fileString2)
    
    xml_string = '<metabolites>\n'
    
    items = mydoc.getElementsByTagName('creation_date')
    for node in items:
        xml_string = xml_string + node.toxml() + '\n'
        
    print(xml_string)
        
    items = mydoc.getElementsByTagName('update_date')
    for node in items:
        xml_string = xml_string + node.toxml() + '\n'
        
    items = mydoc.getElementsByTagName('accession')
    for node in items:
        xml_string = xml_string + node.toxml() + '\n'
        break ## according to template A only the first accession number required
        
    items = mydoc.getElementsByTagName('name')
    for node in items:
        xml_string = xml_string + node.toxml()  + '\n'
        break ## according to template A only the first accession number required
        
    items = mydoc.getElementsByTagName('normal_concentrations')
    for node in items:
        xml_string = xml_string + node.toxml()
        
    items = mydoc.getElementsByTagName('abnormal_concentrations')
    for node in items:
        xml_string = xml_string + node.toxml()
        
    items = mydoc.getElementsByTagName('diseases')
    for node in items:
        xml_string = xml_string + node.toxml()
        
    xml_string = xml_string + '\n</metabolites>'
    
    myfile = open("/home/guest/Desktop/outputFiles/modifiedXML" + numString2 + ".xml","w")
    myfile.write(xml_string)
    
    
    
    
"""
    Part 6 - 7
"""

"""
    metabolites
        creation_date
        update_date
        version
        name (first one only)
        accession (first one only)
        completion_status (in progress)
        ranges
            range
                sex
                age
                    min
                    max
                ethnicity
                unit
                min_range
                max_range
                disease
                    name
                    references
                        reference
                            reference_text
                            pubmed_id
"""

from xml.dom import minidom

for fileNum in XML_with_blood:
    
    numString3 = str(fileNum)
    
    if fileNum < 10:
        numString3 = '0' + numString3

    fileString3 = "/home/guest/Desktop/xml_split_5000/hmdb_metabolites-" + numString3 + ".xml"
    
    mydoc = minidom.parse(fileString3)
    
    xml_string = '<metabolites>\n'
    
    items = mydoc.getElementsByTagName('creation_date')
    for node in items:
        xml_string = xml_string + node.toxml() + '\n'
        
    items = mydoc.getElementsByTagName('update_date')
    for node in items:
        xml_string = xml_string + node.toxml() + '\n'
        
    #print(xml_string)
    
    items = mydoc.getElementsByTagName('version')
    for node in items:
        xml_string = xml_string + node.toxml() + '\n'
        
    items = mydoc.getElementsByTagName('name')
    for node in items:
        xml_string = xml_string + node.toxml()  + '\n'
        break ## according to template A only the first accession number required
        
    items = mydoc.getElementsByTagName('accession')
    for node in items:
        xml_string = xml_string + node.toxml() + '\n'
        break ## according to template A only the first accession number required
        

    xml_string = xml_string + '<completion_status>In progress</completion_status>'
    
    xml_string = xml_string + '<ranges>'
    
    xml_string = xml_string + '<range>'
        
    items = mydoc.getElementsByTagName('abnormal_concentrations')
    for node in items:
        xml_string = xml_string + node.toxml()
        
    items = mydoc.getElementsByTagName('diseases')
    for node in items:
        xml_string = xml_string + node.toxml()
        
    xml_string = xml_string + '</range>'
    
    xml_string = xml_string + '</ranges>'
    
    items = mydoc.getElementsByTagName('reference')
    for node in items:
        xml_string = xml_string + node.toxml() + '\n'
        break
    
    xml_string = xml_string + '\n</metabolites>'
    

        
    
    myfile = open("/home/guest/Desktop/outputFiles/modifiedXML_step7" + numString3 + ".xml","w")
    myfile.write(xml_string)