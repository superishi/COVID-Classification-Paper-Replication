# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 19 14:45:49 2021
@author: guest
"""

"""
    website to scrap ids from: https://www.metagene.de/v2020/diseases.prg?act=getData&dhxr1611207022398=1
    urls from website:
        disease: https://www.metagene.de/v2020/diseases.prg?act=show&id=458
        symptoms: https://www.metagene.de/v2020/symptoms.prg?act=getGridData&id_d=1098
        normal: https://www.metagene.de/appl/normal.prg?act=getData&id_d=458
        literature: https://www.metagene.de/appl/authors.prg?act=getGridData&withLink=1&id_d=458
"""

from bs4 import BeautifulSoup
import requests
import re
import xml.etree.ElementTree as xml
import copy

def idExtract():
    id_url="https://www.metagene.de/v2020/diseases.prg?act=getData&dhxr1611207022398=1"
    id_text = requests.get(id_url)    
    id_text = BeautifulSoup(id_text.content,'html.parser')    
    id_text = str(id_text) 
    result = re.findall('id:(.*?),data:', id_text)
    #print(result)
    return result



""" disease link """
def diseaseExtract(idNo, baseTree):
    disease_url =  "https://www.metagene.de/v2020/diseases.prg?act=show&id=" + idNo
    
    disease_text = requests.get(disease_url)
    
    disease_text = BeautifulSoup(disease_text.content,'html.parser')
    
    #print(disease_text.prettify())
    
    name = disease_text.find('td', class_='tr0').text
    
    d_name = xml.Element("Name")
    d_name.text = name
    baseTree.append(d_name)
    
    #print(name)

    synonym = disease_text.find('td', class_='tr1').text
    
    d_syn = xml.Element("Synonym")
    d_syn.text = synonym
    baseTree.append(d_syn)
    
    #print(synonym)
    
    i = 0
    for node in disease_text.find_all('tr'):
        if (i == 2):
            OMIMNum = node.a.text
            OMIMComment = "OMIM = Online Mendelian Inheritance of Men"
            OMIMUrl = node.a['href']
            
            d_OMIM = xml.Element("OMIM")
            baseTree.append(d_OMIM)
            
            d_OMIM_num = xml.Element("Number")
            d_OMIM_num.text = OMIMNum
            d_OMIM.append(d_OMIM_num)
            
            d_OMIM_comment = xml.Element("Comment")
            d_OMIM_comment.text = OMIMComment
            d_OMIM.append(d_OMIM_comment)
            
            d_OMIM_URL = xml.Element("URL")
            d_OMIM_URL.text = OMIMUrl
            d_OMIM.append(d_OMIM_URL)
            

            #print(OMIMNum)
            #print(OMIMUrl)
            #print(OMIM)
        if (i == 3):
            orphanetNum = node.a.text
            orphanetUrl = node.a['href']
            
            d_Orphanet = xml.Element("Orphanet")
            baseTree.append(d_Orphanet)
            
            d_Orphanet_num = xml.Element("Number")
            d_Orphanet_num.text = orphanetNum
            d_Orphanet.append(d_Orphanet_num)
            
            d_Orphanet_URL = xml.Element("URL")
            d_Orphanet_URL.text = orphanetUrl
            d_Orphanet.append(d_Orphanet_URL)
            #print(orphanetNum)
            #print(orphanetUrl)
        if (i == 4):
            proteinNum = node.a.text
            proteinUrl = node.a['href']
            
            d_protein = xml.Element("Protein")
            baseTree.append(d_protein)
            
            d_protein_num = xml.Element("Number")
            d_protein_num.text = proteinNum
            d_protein.append(d_protein_num)
            
            d_protein_URL = xml.Element("URL")
            d_protein_URL.text = proteinUrl
            d_protein.append(d_protein_URL)
            #print(proteinNum)
            #print(proteinUrl)
        if (i == 5):
            pasyNum = node.a.text
            pasyUrl = node.a['href']
            
            d_pasy = xml.Element("ExPASy")
            baseTree.append(d_pasy)
            
            d_pasy_num = xml.Element("Number")
            d_pasy_num.text = pasyNum
            d_pasy.append(d_pasy_num)
            
            d_pasy_URL = xml.Element("URL")
            d_pasy_URL.text = pasyUrl
            d_pasy.append(d_pasy_URL)
            #print(pasyNum)
            #print(pasyUrl)
        if (i == 6):
            geneNum = node.td.text[10:]
            
            d_gene = xml.Element("Gene")
            baseTree.append(d_gene)
            d_gene.text = geneNum
            #print(geneNum)
        if (i == 7):
            ICDNum = node.td.text[3:]
            
            d_ICD = xml.Element("ICD")
            baseTree.append(d_ICD)
            d_ICD.text = ICDNum
            #print(ICDNum)
        if (i == 8):
            for node2 in node.find_all('td'):
                summary = node2.text
                
            d_summary = xml.Element("Summary")
            d_summary.text = summary
            baseTree.append(d_summary)
            #print(summary)
        i = i + 1
        
        
        
        
def symptomsExtract(idNo, baseTree):
    symptoms_url =  "https://www.metagene.de/v2020/symptoms.prg?act=getGridData&id_d=" + idNo
    
    symptoms_text = requests.get(symptoms_url)
    
    symptoms_text = BeautifulSoup(symptoms_text.content,'html.parser')
    
    symptoms_text = symptoms_text.text[9:-2]
    
    symptoms_text = symptoms_text.split("},{")
    
    s_Symptoms = xml.Element("Symptoms")
    
    for object in symptoms_text:
        #print(object)
        symptoms_id = re.findall('"id":(.*?),"data":', object)[0]
        symptoms_symptom = re.findall('"data":\["(.*?)","', object)[0]
        symptoms_category = re.findall('","(.*?)"\]', object)[0]
        
        s_Symptom = xml.Element("Symptom")
            
        s_id = xml.Element("id")
        s_id.text = symptoms_id
        s_Symptom.append(s_id)
            
        s_symptom = xml.Element("symptom")
        s_symptom.text = symptoms_symptom
        s_Symptom.append(s_symptom)
            
        s_category = xml.Element("category")
        s_category.text = symptoms_category
        s_Symptom.append(s_category)
        
        s_Symptoms.append(copy.deepcopy(s_Symptom))
        
    baseTree.append(s_Symptoms)  
    
    
def metabolitesExtract(idNo, baseTree):
    metabolites_url =  "https://www.metagene.de/appl/normal.prg?act=getData&id_d=" + idNo
    
    metabolites_text = requests.get(metabolites_url)
    
    metabolites_text = BeautifulSoup(metabolites_text.content,'html.parser')
    
    #print(symptoms_text)
    
    metabolites_text = metabolites_text.text[9:-2]
    
    metabolites_text = metabolites_text.split("},{")
    
    m_Metabolites = xml.Element("Metabolites")
    
    for object in metabolites_text:
        #print(object)
        metabolites_id = re.findall('"id":(.*?),"data":', object)[0]
        metabolites_name = re.findall('"(.*?)"', object)[2]
        metabolites_specimen = re.findall('"(.*?)"', object)[6]
        metabolites_value = "Not available"
        metabolites_min = re.findall('"(.*?)"', object)[3]
        metabolites_max = re.findall('"(.*?)"', object)[4]
        metabolites_unit = re.findall('"(.*?)"', object)[5]
        metabolites_age = re.findall('"(.*?)"', object)[7]
        metabolites_method = ""
        metabolites_comment = ""
        
        m_metabolite = xml.Element("metabolite")
            
        m_id = xml.Element("id")
        m_id.text = metabolites_id
        m_metabolite.append(m_id)
            
        m_name = xml.Element("name")
        m_name.text = metabolites_name
        m_metabolite.append(m_name)
        
        m_specimen = xml.Element("specimen")
        m_specimen.text = metabolites_specimen
        m_metabolite.append(m_specimen)       
        
        m_value = xml.Element("value")
        m_value.text = metabolites_value
        m_metabolite.append(m_value) 
        
        m_min = xml.Element("min")
        m_min.text = metabolites_min
        m_metabolite.append(m_min) 
        
        m_max = xml.Element("max")
        m_max.text = metabolites_max
        m_metabolite.append(m_max) 
        
        m_unit = xml.Element("unit")
        m_unit.text = metabolites_unit
        m_metabolite.append(m_unit) 
        
        m_age = xml.Element("age")
        m_age.text = metabolites_age
        m_metabolite.append(m_age) 
        
        m_method = xml.Element("method")
        m_method.text = metabolites_method
        m_metabolite.append(m_method) 
        
        m_comment = xml.Element("comment")
        m_comment.text = metabolites_comment
        m_metabolite.append(m_comment) 
        
        m_Metabolites.append(copy.deepcopy(m_metabolite))
        
    baseTree.append(m_Metabolites)  



def literatureExtract(idNo, baseTree):
    literature_url =  "https://www.metagene.de/appl/authors.prg?act=getGridData&withLink=1&id_d=" + idNo
    
    literature_text = requests.get(literature_url)
    
    literature_text = BeautifulSoup(literature_text.content,'html.parser')   

    literature_text = literature_text.text[9:-2]
    
    literature_text = literature_text.split("},{")
    
    l_Literatures = xml.Element("Literatures")
    
    for object in literature_text: 
        #print(object)
        literature_id = re.findall('"id":(.*?),"data":', object)[0]
        literature_title = re.findall('"(.*?)"', object)[2]
        literature_author = re.findall('"(.*?)"', object)[3]
        literature_journal = re.findall('"(.*?)"', object)[4]
        literature_year = re.findall('"(.*?)"', object)[5]
        literature_book = re.findall('"(.*?)"', object)[6]
        literature_volume = re.findall('"(.*?)"', object)[7]
        literature_number = re.findall('"(.*?)"', object)[8]
        literature_pages = re.findall('"(.*?)"', object)[9]
        literature_coAuthor = re.findall('"(.*?)"', object)[10]
        
        l_literature = xml.Element("literature")
            
        l_id = xml.Element("id")
        l_id.text = literature_id
        l_literature.append(l_id)
            
        l_title = xml.Element("title")
        l_title.text = literature_title
        l_literature.append(l_title)
        
        l_author = xml.Element("author")
        l_author.text = literature_author
        l_literature.append(l_author)      
        
        l_journal = xml.Element("journal")
        l_journal.text = literature_journal
        l_literature.append(l_journal)
        
        l_year = xml.Element("year")
        l_year.text = literature_year
        l_literature.append(l_year)
        
        l_book = xml.Element("book")
        l_book.text = literature_book
        l_literature.append(l_book)
        
        l_volume = xml.Element("volume")
        l_volume.text = literature_volume
        l_literature.append(l_volume)
        
        l_number = xml.Element("number")
        l_number.text = literature_number
        l_literature.append(l_number)
        
        l_pages = xml.Element("pages")
        l_pages.text = literature_pages
        l_literature.append(l_pages)
        
        l_coAuthor = xml.Element("coAuthor")
        l_coAuthor.text = literature_coAuthor
        l_literature.append(l_coAuthor)
        
       
        l_Literatures.append(copy.deepcopy(l_literature))
        
    baseTree.append(l_Literatures) 

def GenerateXML(idNo):
    root = xml.Element("Disease")
    diseaseExtract(idNo, root)
    symptomsExtract(idNo, root)
    metabolitesExtract(idNo, root)
    literatureExtract(idNo, root)
    finalTree = xml.ElementTree(root)
    
    fileName = "webScaperXML" + idNo
    
    with open(fileName, "wb") as files:
        finalTree.write(files, short_empty_elements=False)
        
    
idList = idExtract()

for id in idList:  
    try:
        print(id)
        GenerateXML(id) 
    except: 
        print("Incomplete information for XML formation")
