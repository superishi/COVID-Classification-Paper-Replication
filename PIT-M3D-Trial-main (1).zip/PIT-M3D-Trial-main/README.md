# PIT-M3D-Trial
Files related to the PIT-M3D Trial


COVID-19 File is for exercise 3

csv file is for exercise 1 part 3

modifiedXML files are for exercise 1 part 5

modifiedXML_step7 files are for exercise 1 part 7 (some features left out)

web_scraper.py contains all the code for Exercise 2, and the webscraperXML files are sample XML output files.
